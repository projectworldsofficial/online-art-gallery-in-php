<div class="col-md-3 my_cart_container">
	<div class="my_cart">
        <h3>MyCart</h3>
		<div class="cart_items">
			<ol>
				<li><img src="images/Taj%20Mahal.jpeg" alt="Taj Mahal" class="my_cart_items"> <span class="my_cart_items_title">Taj Mahal</span> <span class="my_cart_items_price">Rs. 250</span></li>
            </ol>
        </div>
	</div>
</div>	